/*
graph.c

Set of vertices and edges implementation.

Implementations for helper functions for graph construction and manipulation.

Skeleton written by Grady Fitzpatrick for COMP20007 Assignment 1 2021
*/
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include "graph.h"
#include "utils.h"
#include "pq.h"

#define INITIALEDGES 32

struct edge;

/* Definition of a graph. */
struct graph {
  int numVertices;
  int numEdges;
  int allocedEdges;
  struct edge **edgeList;
};

/* Definition of an edge. */
struct edge {
  int start;
  int end;
  int cost;
};

struct graph *newGraph(int numVertices){
  struct graph *g = (struct graph *) malloc(sizeof(struct graph));
  assert(g);
  /* Initialise edges. */
  g->numVertices = numVertices;
  g->numEdges = 0;
  g->allocedEdges = 0;
  g->edgeList = NULL;
  return g;
}

/* Adds an edge to the given graph. */
void addEdge(struct graph *g, int start, int end, int cost){
  assert(g);
  struct edge *newEdge = NULL;
  /* Check we have enough space for the new edge. */
  if((g->numEdges + 1) > g->allocedEdges){
    if(g->allocedEdges == 0){
      g->allocedEdges = INITIALEDGES;
    } else {
      (g->allocedEdges) *= 2;
    }
    g->edgeList = (struct edge **) realloc(g->edgeList,
      sizeof(struct edge *) * g->allocedEdges);
    assert(g->edgeList);
  }

  /* Create the edge */
  newEdge = (struct edge *) malloc(sizeof(struct edge));
  assert(newEdge);
  newEdge->start = start;
  newEdge->end = end;
  newEdge->cost = cost;

  /* Add the edge to the list of edges. */
  g->edgeList[g->numEdges] = newEdge;
  (g->numEdges)++;
}

/* Frees all memory used by graph. */
void freeGraph(struct graph *g){
  int i;
  for(i = 0; i < g->numEdges; i++){
    free((g->edgeList)[i]);
  }
  if(g->edgeList){
    free(g->edgeList);
  }
  free(g);
}

/* Returns the sum of all edges in the given MST. */
int getMSTCost(struct graph *g);

int getMSTCost(struct graph *g){
  int *mstRoot = (int *) malloc(sizeof(int) * g->numVertices);
  int mstSize = 0;
  int costSum = 0;
  struct edge *candidate;
  assert(mstRoot);
  int i;
  for(i = 0; i < g->numVertices; i++){
    mstRoot[i] = i;
  }
  struct pq *pq = newPQ();
  for(i = 0; i < g->numEdges; i++){
    enqueue(pq, (void *) ((g->edgeList)[i]), ((g->edgeList)[i])->cost);
  }
  while(! empty(pq)){
    candidate = (struct edge *) deletemin(pq);
    if(mstRoot[candidate->start] != mstRoot[candidate->end]){
      // printf("Adding %d to %d (%d)\n", candidate->start, candidate->end, candidate->cost);
      mstSize++;
      costSum += candidate->cost;
      int replace = mstRoot[candidate->start];
      for(i = 0; i < g->numVertices; i++){
        if(mstRoot[i] == replace){
          mstRoot[i] = mstRoot[candidate->end];
        }
        // printf("%d ", mstRoot[i]);
      }
      // printf("\n");
      if(mstSize == (g->numVertices - 1)){
        /* Built full MST. */
        break;
      }
    }
  }
  if(mstSize != (g->numVertices - 1)){
    freePQ(pq);
    free(mstRoot);
    return INT_MAX;
  }
  freePQ(pq);
  free(mstRoot);
  return costSum;
}

struct solution *graphSolve(struct graph *g, enum problemPart part,
  int antennaCost, int numHouses){
  struct solution *solution = (struct solution *)
    malloc(sizeof(struct solution));
  assert(solution);
  if(part == PART_A){
    /* IMPLEMENT 2A SOLUTION HERE */
    solution->antennaTotal = numHouses * antennaCost;
    solution->cableTotal = getMSTCost(g);

  } else {
    /* IMPLEMENT 2C SOLUTION HERE */
    int i;
    for(i = 1; i <= numHouses; i++){
      addEdge(g, 0, i, antennaCost);
    }
    solution->mixedTotal = getMSTCost(g);
  }
  return solution;
}

